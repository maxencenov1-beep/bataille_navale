<?php
require_once 'classes/Partie.php';
require_once 'classes/JoueurHumain.php';
require_once 'classes/JoueurOrdinateur.php';
require_once 'classes/Grille.php';
require_once 'classes/Navire.php';
session_start();
$stats = $_SESSION['fin_partie'];
if (!$stats) {
    header('Location: index.php');
    exit();
}
unset($_SESSION['fin_partie']);
unset($_SESSION['game']);

$victoire        = $stats['victoire'];
$nomJoueur       = htmlspecialchars($stats['nom_joueur']);
$role            = htmlspecialchars($stats['role_joueur']);
$tirsJoueur      = $stats['tirs_joueur'];
$touchesJoueur   = $stats['touches_joueur'];
$tirsOrdi        = $stats['tirs_ordi'];
$touchesOrdi     = $stats['touches_ordi'];
$duree           = $stats['duree'];

$precisionJoueur = $tirsJoueur > 0 ? round($touchesJoueur / $tirsJoueur * 100) : 0;
$precisionOrdi   = $tirsOrdi   > 0 ? round($touchesOrdi   / $tirsOrdi   * 100) : 0;

$minutes  = floor($duree / 60);
$secondes = $duree % 60;
$dureeStr = $minutes > 0 ? "{$minutes}m {$secondes}s" : "{$secondes}s";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bataille Navale – Fin de partie</title>
    <link rel="stylesheet" href="css/game.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet">
    <style>
        :root {
            --or:    #c9a84c;
            --rouge: #8b1a1a;
            --bleu:  #0a1628;
            --bleu2: #122040;
            --texte: #e8dcc8;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Crimson Pro', Georgia, serif;
            background: var(--bleu);
            color: var(--texte);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        /* Fond vagues */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background:
                repeating-linear-gradient(
                    0deg,
                    transparent,
                    transparent 38px,
                    rgba(12,100,160,.08) 38px,
                    rgba(12,100,160,.08) 40px
                ),
                linear-gradient(160deg, #071020 0%, #0d2240 50%, #071830 100%);
            z-index: 0;
        }

        .carte {
            position: relative;
            z-index: 1;
            width: min(520px, 92vw);
            background: linear-gradient(145deg, #0f1e3a, #1a2e50);
            border: 1px solid rgba(201,168,76,.35);
            border-radius: 4px;
            padding: 48px 40px 40px;
            box-shadow:
                0 0 0 1px rgba(201,168,76,.1),
                0 32px 80px rgba(0,0,0,.7),
                inset 0 1px 0 rgba(201,168,76,.2);
            animation: apparition .7s cubic-bezier(.22,1,.36,1) both;
        }
        @keyframes apparition {
            from { opacity: 0; transform: translateY(28px) scale(.97); }
            to   { opacity: 1; transform: none; }
        }

        /* Filet décoratif */
        .carte::before, .carte::after {
            content: '';
            position: absolute;
            left: 16px; right: 16px;
            height: 1px;
            background: linear-gradient(90deg, transparent, var(--or), transparent);
        }
        .carte::before { top: 16px; }
        .carte::after  { bottom: 16px; }

        .victoire-label {
            font-family: 'Cinzel Decorative', serif;
            font-size: .7rem;
            letter-spacing: .3em;
            text-transform: uppercase;
            color: var(--or);
            opacity: .8;
            text-align: center;
            margin-bottom: 10px;
        }

        h1 {
            font-family: 'Cinzel Decorative', serif;
            font-size: clamp(1.5rem, 4vw, 2.2rem);
            font-weight: 700;
            text-align: center;
            line-height: 1.2;
            margin-bottom: 6px;
            color: #fff;
            text-shadow: 0 0 30px rgba(201,168,76,.4);
        }

        .sous-titre {
            text-align: center;
            font-style: italic;
            font-size: 1.05rem;
            color: rgba(232,220,200,.55);
            margin-bottom: 36px;
        }

        /* Stats */
        .stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 36px;
        }
        .stat-bloc {
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(201,168,76,.15);
            border-radius: 3px;
            padding: 16px 14px 14px;
            text-align: center;
            transition: background .25s;
        }
        .stat-bloc:hover { background: rgba(201,168,76,.07); }

        .stat-valeur {
            font-family: 'Cinzel Decorative', serif;
            font-size: 1.7rem;
            color: var(--or);
            line-height: 1;
            margin-bottom: 6px;
        }
        .stat-label {
            font-size: .78rem;
            letter-spacing: .12em;
            text-transform: uppercase;
            color: rgba(232,220,200,.5);
        }

        /* Séparateur */
        .sep {
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(201,168,76,.3), transparent);
            margin: 0 0 32px;
        }

        /* Bouton */
        .btn {
            display: block;
            width: 100%;
            padding: 15px;
            font-family: 'Cinzel Decorative', serif;
            font-size: .85rem;
            letter-spacing: .18em;
            text-align: center;
            text-decoration: none;
            color: var(--bleu);
            background: linear-gradient(135deg, #d4a843, #c9a84c, #b8923d);
            border: none;
            border-radius: 2px;
            cursor: pointer;
            transition: filter .25s, transform .2s, box-shadow .25s;
            box-shadow: 0 4px 20px rgba(201,168,76,.25);
        }
        .btn:hover {
            filter: brightness(1.12);
            transform: translateY(-2px);
            box-shadow: 0 8px 28px rgba(201,168,76,.4);
        }
        .btn:active { transform: translateY(0); }

        /* icône ancre */
        .ancre {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 16px;
            opacity: .5;
            animation: flottement 3s ease-in-out infinite;
        }
        @keyframes flottement {
            0%, 100% { transform: translateY(0); }
            50%       { transform: translateY(-5px); }
        }
    </style>
</head>
<body>
<div class="carte">
    <div class="ancre">⚓</div>
    <p class="victoire-label">
<?php 
    if ($victoire === true) echo 'Victoire';
    elseif ($victoire === false) echo 'Défaite';
    else echo 'Partie nulle';
?>
    </p>

    <h1>
<?php 
    if ($victoire === true) echo 'Bravo, ' . $role . ' ' . $nomJoueur;
    elseif ($victoire === false) echo 'Coulé, ' . $role . ' ' . $nomJoueur;
    else echo 'Match nul, ' . $role . ' ' . $nomJoueur;
?>
    </h1>

    <p class="sous-titre">
<?php 
    if ($victoire === true) echo 'Vous avez anéanti la flotte ennemie.';
    elseif ($victoire === false) echo 'L\'ordinateur a détruit votre flotte.';
    else echo 'Vous avez proposé une partie nulle.';
?>
    </p>

    <div class="stats">
        <div class="stat-bloc">
            <div class="stat-valeur"><?php echo $tirsJoueur; ?></div>
            <div class="stat-label">Tirs effectués</div>
        </div>
        <div class="stat-bloc">
            <div class="stat-valeur"><?php echo $precisionJoueur; ?>%</div>
            <div class="stat-label">Précision</div>
        </div>
        <div class="stat-bloc">
            <div class="stat-valeur"><?php echo $tirsOrdi; ?></div>
            <div class="stat-label">Tirs ennemis</div>
        </div>
        <div class="stat-bloc">
            <div class="stat-valeur"><?php echo $dureeStr; ?></div>
            <div class="stat-label">Durée</div>
        </div>
    </div>

    <div class="sep"></div>
    <a href="index.php" class="btn">Nouvelle partie</a>
</div>

    <!-- Notifications fin de partie -->
    <?php if (!empty($_SESSION['notifications_fin'])): ?>
        <div id="notifications">
            <?php foreach ($_SESSION['notifications_fin'] as $notif): ?>
        <div class="notif <?php echo $notif['type']; ?>">
            <?php echo $notif['message']; ?>
        </div>
    <?php endforeach; ?>
    </div>
<?php unset($_SESSION['notifications_fin']); ?>
<?php endif; ?>

    <script>
        document.querySelectorAll('.notif').forEach(function(notif) {
            setTimeout(function() {
                notif.remove();
            }, 4000);
        });
</script>
</body>
</html>