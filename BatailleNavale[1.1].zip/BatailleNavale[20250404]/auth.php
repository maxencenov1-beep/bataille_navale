<?php
session_start();
require_once 'data/database.php';

$erreur = '';
$succes = '';

if (isset($_POST['action'])) {
    
    if ($_POST['action'] === 'inscription') {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        
        if (empty($username) || empty($password)) {
            $erreur = 'Veuillez remplir tous les champs.';
        } else {
            // Appeler creerJoueur()
            $joueurCree = creerJoueur($username, $password);
            // Si true → $succes = '...'
            if ($joueurCree) {
                $succes = 'Inscription réussie ! Vous pouvez maintenant vous connecter.';
            } 
            // Si false → $erreur = '...'
            else {
                $erreur = 'Une erreur est survenue lors de l\'inscription. Veuillez réessayer.';
            }
        }
    }  
    if ($_POST['action'] === 'connexion') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    $joueur = connecterJoueur($username, $password);
    
    if ($joueur) {
        // Stocker en session et rediriger
        $_SESSION['username'] = $joueur['username'];
        header('Location: index.php');
        exit();
    } else {
        $erreur = 'Nom d\'utilisateur ou mot de passe incorrect.';
    }
}
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bataille Navale</title>
    <link rel="stylesheet" href="css/auth.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet">
</head>
<body>

    <div class="container">
    <h1>Connexion / Inscription</h1>
    
    <?php if ($erreur): ?>
        <p class="erreur"><?php echo $erreur; ?></p>
    <?php endif; ?>
    
    <?php if ($succes): ?>
        <p class="succes"><?php echo $succes; ?></p>
    <?php endif; ?>

        <!-- Formulaire inscription -->
<form action="auth.php" method="post">
    <input type="hidden" name="action" value="inscription">
    <!-- champ username -->
    <input type="text" name="username" placeholder="Nom d'utilisateur">
    <!-- champ password -->
    <input type="password" name="password" placeholder="Mot de passe">
    <!-- bouton submit -->
    <button type="submit">S'inscrire</button>
</form>

<!-- Formulaire connexion -->
<form action="auth.php" method="post">
    <input type="hidden" name="action" value="connexion">
    <!-- champ username -->
    <input type="text" name="username" placeholder="Nom d'utilisateur">
    <!-- champ password -->
    <input type="password" name="password" placeholder="Mot de passe">
    <!-- bouton submit -->
    <button type="submit">Se connecter</button>
</form>
    
    <button><a href="index.php">Retour au menu</a></button>
</div>
</body>
</html>
