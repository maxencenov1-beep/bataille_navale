<?php
session_start();
require_once 'data/database.php';

$classement   = getClassement();
$statsGlobales = getStatsGlobales();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Classement – Bataille Navale</title>
    <link rel="stylesheet" href="css/classement.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet">
</head>
<body>
<div class="container">

    <h1>Classement</h1>

    <!-- Stats globales communauté -->
    <h2>Statistiques de la communauté</h2>
    <p>Connectez-vous pour être dans le classement</p>
    <div class="stats-globales">
        <div class="stat-bloc">
            <div class="stat-valeur"><?php echo $statsGlobales['total_joueurs']; ?></div>
            <div class="stat-label">Joueurs inscrits</div>
        </div>
        <div class="stat-bloc">
            <div class="stat-valeur"><?php echo $statsGlobales['total_parties']; ?></div>
            <div class="stat-label">Parties jouées</div>
        </div>
        <div class="stat-bloc">
            <div class="stat-valeur"><?php echo $statsGlobales['precision_moy']; ?>%</div>
            <div class="stat-label">Précision moyenne</div>
        </div>
    </div>

    <div class="sep"></div>

    <!-- Classement joueurs -->
    <h2>Classement des joueurs</h2>
    <table>
        <thead>
            <tr>
                <th>Joueur</th>
                <th>Parties</th>
                <th>Victoires</th>
                <th>Défaites</th>
                <th>Nuls</th>
                <th>Précision</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($classement as $joueur): ?>
            <tr>
                <td><?php echo htmlspecialchars($joueur['username']); ?></td>
                <td><?php echo $joueur['parties_jouees']; ?></td>
                <td><?php echo $joueur['parties_gagnees']; ?></td>
                <td><?php echo $joueur['parties_perdues']; ?></td>
                <td><?php echo $joueur['parties_nul']; ?></td>
                <td><?php echo $joueur['precision']; ?>%</td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="sep"></div>
    <button><a href="index.php">Retour</a></button>
</div>
</body>
</html>