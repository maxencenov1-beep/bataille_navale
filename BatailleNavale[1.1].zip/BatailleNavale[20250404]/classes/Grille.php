<?php
class Grille
{

    /**
     * Constantes utilisées dans le fichier game.css
     */
    CONST CSS_COUP_RATE = 'coupRate';
    CONST CSS_COUP_TOUCHE = 'coupTouche';
    CONST CSS_COUP_COULE = 'coupCoule';
    CONST CSS_NAVIRE_ORDINATEUR = 'navireOrdinateur';
    CONST CSS_NAVIRE_JOUEUR = 'navireJoueur';

    /**
     * @var array Tableau dont les cases représentent la grille de jeu
     */
    private array $grille;

    /**
     * @var array Tableau contenant les différents navires
     */
    private array $navires;

    /**
     * @var string Contient le nom de la classe css à utiliser pour l'affichage des navires
     */
    private $cssNavire;

    /**
     * Initialise l'affichage de la grille
     * @param $estGrilleEnnemi utilisé pour éviter l'affichage des navires enemis dans la grille
     */
    public function __construct($estGrilleEnnemi)
    {
        $this->grille = array_fill(0, 20, array_fill(0, 20, ''));
        $this->navires = [];
        if ($estGrilleEnnemi)
        {
            $this->cssNavire = self::CSS_NAVIRE_ORDINATEUR;
        }
        else
        {
            $this->cssNavire = self::CSS_NAVIRE_JOUEUR;

        }
    }

    /** Place les navires aléatoirement dans la grille
     * Une vérification de la disponibilité des cases est réalisée
     * @return void
     */
    public function placeNaviresAleatoirement()
    {
        $tailleNavires = [5, 4, 3, 3, 2]; // Exemple de tailles de bateaux
        foreach ($tailleNavires as $taille)
        {
            $estPlace = false;
            while (!$estPlace) {
                $x = rand(0, 19);
                $y = rand(0, 19);
                $orientation = rand(0, 1) ? 'horizontal' : 'vertical';
                $navire = new Navire($taille);
                if ($this->peutPlacerNavire($navire, $x, $y, $orientation))
                {
                    $navire->placeNavire($x, $y, $orientation);
                    $this->navires[] = $navire;
                    $this->majGrilleAvecNavire($navire);
                    $estPlace = true;
                }
            }
        }
    }

    /**
     * Permet de déterminer si un navire peut être placé à la position indiquée sur la grille
     * La taille du navire et son oientation sont prises en compte, ainsi que la détection des bords
     * @param unNavire
     * @param x colone ou placer le navire
     * @param y ligne ou placer le navire
     * @param orientation du navire 'horizontal' ou 'vertical'
     * @return bool Renvoie vrai si le navire peut être placé
     */
    private function peutPlacerNavire($unNavire, $x, $y, $orientation)
    {
        for ($i = 0; $i < $unNavire->getTaille(); $i++)
        {
            if ($orientation === 'horizontal' &&
                ($x + $i >= 20 || $this->grille[$y][$x + $i] !== ''))
            {
                return false;
            }
            if ($orientation === 'vertical' &
                ($y + $i >= 20 || $this->grille[$y + $i][$x] !== ''))
            {
                return false;
            }
        }
        return true;
    }

    /**
     * Met à jour l'affichage de la grille avec le navire
     * @param unNavire Le navire a afficher sur la grille
     * @return void
     */
    private function majGrilleAvecNavire($unNavire)
    {
        foreach ($unNavire->getPosition() as $pos)
        {
            list($x, $y) = $pos;
            $this->grille[$y][$x] = $this->cssNavire;
        }
    }

    /**
     * Mise à jour de l'état de la case après un tir sur la position
     * @param x colonne de la grille
     * @param y ligne de la grille
     * @return string
     */
    public function majEtatCaseApresTir($x, $y)
    {
        if ($this->grille[$y][$x] == $this->cssNavire)
        {
            $this->grille[$y][$x] = self::CSS_COUP_TOUCHE;
            foreach ($this->navires as $ship)
            {
                if ($ship->estTouche($x, $y))
                {
                    if ($ship->estCoule())
                    {
                        foreach ($ship->getPosition() as $pos)
                        {
                            list($sx, $sy) = $pos;
                            $this->grille[$sy][$sx] = self::CSS_COUP_COULE;
                        }
                        return self::CSS_COUP_COULE;
                    }
                    return self::CSS_COUP_TOUCHE;
                }
            }
        }
        else
        {
            if ($this->grille[$y][$x] == '')
            {
                $this->grille[$y][$x] = self::CSS_COUP_RATE;
                return self::CSS_COUP_RATE;
            }
        }
        return 'repeat';
    }

    /**
     * Permet de détecter si tous les navires ont été coulés
     * @return bool
     */
    public function toutNaviresCoules()
    {
        foreach ($this->navires as $navire)
        {
            if (!$navire->estCoule())
            {
                return false;
            }
        }
        return true;
    }

    /**
     * Renvoie la grille de jeu
     * @return array La grille de jeu
     */
    public function getGrille()
    {
        return $this->grille;
    }

    /** PERMET L'AFFICHAGE DES STATISTIQUES IG */
    /**
     * Renvoie le nombre de navires restants à couler
     * @return int Le nombre de navires restants
     */
    public function getNbNaviresRestants()
    {
        $compteur = 0;
            foreach ($this->navires as $navire) {
                if (!$navire->estCoule()) {
                    $compteur++;
                }
            }
        return $compteur;
        }
    
/**  FIN DE PERMET L'AFFICHAGE DES STATISTIQUES IG */

/** 
 * Renvoie la liste des navires de la grille
 * @return array La liste des navires
 */
public function getNavires(): array
{
    return $this->navires;
}

}