<?php
class JoueurHumain
{
    /**
     * @var string Nom du joueur
     */
    protected string $nom;

    /**
     * @var string Rôle du joueur
     */
    protected string $role;

    /**
     * @var Grille Grille associée au joueur
     */
    protected Grille $grille;

    /**
     * Constructeur du joueur
     * @param string $unNom Nom du joueur
     * @param string $unRole Rôle du joueur
     */
    public function __construct(string $unNom, string $unRole)
    {
        $this->nom = $unNom;
        $this->role = $unRole;
        $this->grille = new Grille(false);
        $this->grille->placeNaviresAleatoirement();
    }

    /**
     * Renvoie le nom du joueur
     * @return string Nom du joueur
     */
    public function getNom() : string
    {
        return $this->nom;
    }
    
    /**
     * Renvoie le rôle du joueur
     * @return string Rôle du joueur
     */
    public function getRole() : string
    {
        return $this->role;
    }

    /**
     * Définit un tir sur la grille
     * @param int $x colonne de tir dans la grille
     * @param int $y ligne de tir dans la grille
     * @return void
     */
    public function tirerSurLaCase(int $x, int $y)
    {
        return $this->grille->majEtatCaseApresTir($x, $y);
    }

    /**
     * Renvoie la grille de jeu associée au joueur
     * @return Grille La grille de jeu
     */
    public function getGrille() : Grille
    {
        return $this->grille;
    }
}
