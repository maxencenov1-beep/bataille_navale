<?php
class joueurOrdinateur extends JoueurHumain
{
    private string $difficulte;
    private array $casesDejaTirees = [];
    private array $ciblesTouches = [];  // cases touchées à explorer autour

    public function __construct(string $difficulte = 'facile')
    {
        $noms = ["Ordinateur de fou", "L'ordi boosté", "Commandant robot", "Ordi bit"];
        $this->nom = $noms[array_rand($noms)];
        $this->difficulte = $difficulte;
        $this->grille = new Grille(true);
        $this->grille->placeNaviresAleatoirement();
    }

    public function choisirCase(array $grilleJoueur): array
    {
        return match($this->difficulte) {
            'nul'       => $this->jouerNul(),
            'facile'    => $this->jouerFacile(),
            'moyen'     => $this->jouerMoyen($grilleJoueur),
            'difficile' => $this->jouerDifficile($grilleJoueur),
            'impossible'=> $this->jouerImpossible($grilleJoueur),
            default     => $this->jouerFacile(),
        };
    }

    // NUL : tire parout
    private function jouerNul(): array
    {
        return [rand(0, 19), rand(0, 19)];
    }

    // FACILE : aléatoire sur cases non jouées
    private function jouerFacile(): array
    {
        do {
            $x = rand(0, 19);
            $y = rand(0, 19);
        } while (in_array([$x, $y], $this->casesDejaTirees));
        return [$x, $y];
    }

    // MOYEN : aléatoire mais si touche il explore autour
    private function jouerMoyen(array $grille): array
    {
        if (!empty($this->ciblesTouches)) {
            return $this->explorerAutour();
        }
        return $this->jouerFacile();
    }

    // DIFFICILE : damier + explore autour des touches
    private function jouerDifficile(array $grille): array
    {
        if (!empty($this->ciblesTouches)) {
            return $this->explorerAutour();
        }
        // Tir en damier (cases paires)
        $tentatives = 0;
        do {
            $x = rand(0, 19);
            $y = rand(0, 19);
            $tentatives++;
        } while (
            ($x + $y) % 2 !== 0 ||
            in_array([$x, $y], $this->casesDejaTirees) &&
            $tentatives < 100
        );
        return [$x, $y];
    }

    // IMPOSSIBLE (triche): vise directement les navires
    private function jouerImpossible(array $grille): array
    {
        for ($y = 0; $y < 20; $y++) {
            for ($x = 0; $x < 20; $x++) {
                if ($grille[$y][$x] === 'navireJoueur') {
                    return [$x, $y];
                }
            }
        }
    }

    // Explorer les cases autour d'une touche
    private function explorerAutour(): array
    {
        [$cx, $cy] = $this->ciblesTouches[0];
        $directions = [[0,-1],[0,1],[-1,0],[1,0]];
        shuffle($directions);
        foreach ($directions as [$dx, $dy]) {
            $nx = $cx + $dx;
            $ny = $cy + $dy;
            if ($nx >= 0 && $nx < 20 && $ny >= 0 && $ny < 20
                && !in_array([$nx, $ny], $this->casesDejaTirees)) {
                return [$nx, $ny];
            }
        }
        // Plus rien autour, on retire cette posibilite
        array_shift($this->ciblesTouches);
        return $this->jouerFacile();
    }

    public function ajouterTouche(int $x, int $y): void
    {
        $this->ciblesTouches[] = [$x, $y];
    }

    public function ajouterTir(int $x, int $y): void
    {
        $this->casesDejaTirees[] = [$x, $y];
    }

    public function retirerCible(int $x, int $y): void
    {
        $this->ciblesTouches = array_filter(
            $this->ciblesTouches,
            fn($c) => !($c[0] === $x && $c[1] === $y)
        );
    }
}