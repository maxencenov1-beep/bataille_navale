<?php
/**
 * Classe de gestion du navire
 */
class Navire
{
    /**
     * @var int Taille du navire en cases
     */
    private int $taille;

    /**
     * @var array Tanleau contenant les coordonnées des cases occupées par le navire sur la grille
     */
    private array $position;

    /**
     * @var int Nombre de fois où le navire a été touché
     */
    private int $tirTouches;

    /***
     * Constructeur de la classe
     * @param $size Taille du navire en cases
     */
    public function __construct($size)
    {
        $this->taille = $size;
        $this->position = [];
        $this->tirTouches = 0;
    }

    /**
     * Renvoie la taille du navire
     * @return int Taille en nombre de cases
     */
    public function getTaille()
    {
        return $this->taille;
    }

    /**
     * Place un navire sur la grille
     * Aucune vérification de placement n'est effectuée
     * @param $x Colone de la première case du navire
     * @param $y Ligne de la première case du navire
     * @param $orientation Orientation du bateau (horizontal ou vertical)
     * @return void
     */
    public function placeNavire($x, $y, $orientation)
    {
        $this->position = [];
        for ($i = 0; $i < $this->taille; $i++)
        {
            if ($orientation === 'horizontal')
            {
                $this->position[] = [$x+ $i, $y];
            }
            else
            {
                $this->position[] = [$x, $y + $i];
            }
        }
    }

    /**
     * Renvoie le tableau des positions du navire
     * @return array Tableau contenant les coordonnées des cases occupées
     */
    public function getPosition()
    {
        return $this->position;
    }

    /** Détermine si le navire est touché à la position x y
     * @param $x
     * @param $y
     * @return bool vrai si le navire est touché
     */
    public function estTouche($x, $y)
    {
        foreach ($this->position as $index => $pos)
        {
            if ($pos[0] == $x && $pos[1] == $y)
            {
                $this->tirTouches++;
                return true;
            }
        }
        return false;
    }

    /**
     * Determine si un bateau est coulé
     *  @return bool Vrai si le navire est coulé
     */
    public function estCoule()
    {
        return $this->tirTouches >= $this->taille;
    }

    /**
     * Renvoie les points de vie restants du navire
     * @return int Les points de vie restants
     */
    public function getPv(): int
    {
    return $this->taille - $this->tirTouches;
    }

    /**
     * Renvoie le nom du navire en fonction de sa taille
     * @return string Le nom du navire
     */
    public function getNom(): string
    {
    return match($this->taille) {
        5 => 'Porte-avions',
        4 => 'Croiseur',
        3 => 'Destroyer',
        2 => 'Torpilleur',
        default => 'Navire'
        };
    }
}