<?php
require_once __DIR__ . '/../data/database.php';

/**
 * Classe permettant la gestion de la partie :
 * - Alternance des tours
 * - Action des joueurs
 * - Détection de la fin de partie
 * - Association des grilles de jeu à chaque joueur
 */
class Partie
{

    /** Conteneur pour les informations du joueur humain
     * @var JoueurHumain
     */
    private $joueurHumain;

    /** Conteneur pour les informations du joueur Ordinateur
     * @var joueurOrdinateur
     */
    private $joueurOrdinateur;

    /** Tour du jeu
     * @var estTourJoueurHumain
     */
    private $estTourJoueurHumain;

    // --- Statistiques ---
    private int $tirsJoueur  = 0;
    private int $touchesJoueur = 0;
    private int $tirsOrdi    = 0;
    private int $touchesOrdi = 0;
    private int $debutPartie;
    private bool $missileUtilise = false;

    /**
     * Constructeur de la partie
     * @param string $unNomJoueur : nom du joueur
     * @param string $unRoleJoueur : rôle du joueur
     */
    public function __construct($unNomJoueur, $unRoleJoueur, $difficulte = 'facile')
    {
    $this->joueurHumain     = new JoueurHumain($unNomJoueur, $unRoleJoueur);
    $this->joueurOrdinateur = new joueurOrdinateur($difficulte);
    $this->estTourJoueurHumain = true;
    $this->debutPartie = time();
    }

    /**
     * Renvoie le nom de l'ordi
     * @return string : Le nom de l'ordi
     */
    public function getNomOrdinateur() : string
    {
        return $this->joueurOrdinateur->getNom();
    }

    /**
     * Renvoie le nom du joueur
     * @return string : Le nom du joueur
     */
    public function getNomJoueur() : string
    {
        return $this->joueurHumain->getNom();
    }

    /**
     * Renvoie le rôle du joueur
     * @return string : Le rôle du joueur
     */
    public function getRoleJoueur() : string
    {
        return $this->joueurHumain->getRole();
    }

    /**
     * Le joueur humain joue
     * @param int $x : coordonnée x
     * @param int $y : coordonnée y
     * @return void
     */
    public function joueurJoue(int $x, int $y)
    {
        if ($this->estTourJoueurHumain)
        {
            $result = $this->joueurOrdinateur->tirerSurLaCase($x, $y);

            if ($result !== 'repeat')
            {
                $this->tirsJoueur++;
                if ($result === 'coupTouche' || $result === 'coupCoule') {
                    $this->touchesJoueur++;
                }

                $this->estTourJoueurHumain = false;
                if ($this->joueurOrdinateur->getGrille()->toutNaviresCoules())
                {
                    $this->finDePartie(true);
                }
                else
                {
                    $this->ordinateurJoue();
                }
            }
            if ($result === 'coupRate') {
                $this->ajouterNotification('rate', 'Tir raté !');
            } 
            elseif ($result === 'coupTouche') {
                $this->ajouterNotification('touche', 'Navire touché !');
            } 
            elseif ($result === 'coupCoule') {
                $this->ajouterNotification('coule', 'Navire coulé !');
            }
        }
    }

    /**
     * L'ordinateur joue
     * @return void
     */
    public function ordinateurJoue()
    {
    if (!$this->estTourJoueurHumain)
    {
        $grilleJoueur = $this->joueurHumain->getGrille()->getGrille();

        do
        {
            [$x, $y] = $this->joueurOrdinateur->choisirCase($grilleJoueur);
            $result = $this->joueurHumain->tirerSurLaCase($x, $y);
        } while ($result === 'repeat');

        // Mémoriser le tir
        $this->joueurOrdinateur->ajouterTir($x, $y);

        $this->tirsOrdi++;
        if ($result === 'coupTouche' || $result === 'coupCoule') {
            $this->touchesOrdi++;
            // Si touché l'ajouter aux cibles à explorer
            if ($result === 'coupTouche') {
                $this->joueurOrdinateur->ajouterTouche($x, $y);
            }
            // Si coulé, retirer la cible
            if ($result === 'coupCoule') {
                $this->joueurOrdinateur->retirerCible($x, $y);
            }
        }

        $this->estTourJoueurHumain = true;
        if ($this->joueurHumain->getGrille()->toutNaviresCoules())
        {
            $this->finDePartie(false);
        }
    }
}

    /**
     * Renvoie la grille du joueur humain
     * @return array
     */
    public function getJoueurGrille()
    {
        return $this->joueurHumain->getGrille()->getGrille();
    }

    /**
     * Renvoie la grille de l'ordinateur
     * @return array
     */
    public function getOrdinateurGrille()
    {
        return $this->joueurOrdinateur->getGrille()->getGrille();
    }

    /** Determine si c'est au tour du joueur humain de jouer
     * @return bool : vrai si tour du joueur humain
     */
    public function estTourJoueur() : bool
    {
        return $this->estTourJoueurHumain;
    }


    /** PERMET L'AFFICHAGE DES STATISTIQUES IG */

    /**
     * Renvoie le nombre de coups tirés par le joueur humain
     * @return int : Le nombre de coups tirés
     */
    public function getTirsJoueur() : int
    {
        return $this->tirsJoueur;
    }

    /**
     * Renvoie le nombre de coups touchés par le joueur humain
     * @return int : Le nombre de coups touchés
     */
    public function getTouchesJoueur() : int
    {
        return $this->touchesJoueur;
    }

    /**
     * Renvoie le nombre de coups tirés par l'ordinateur
     * @return int : Le nombre de coups tirés
     */
    public function getTirsOrdi() : int
    {
        return $this->tirsOrdi;
    }

    /**
     * Renvoie le nombre de coups touchés par l'ordinateur
     * @return int : Le nombre de coups touchés
     */
    public function getTouchesOrdi() : int
    {
        return $this->touchesOrdi;
    }

    /** FIN DE PERMET L'AFFICHAGE DES STATISTIQUES */

    
    /** DEBUT APPEL DES METHODES DE STATISTIQUES IG */

    public function getNbNaviresRestantsHumain() {
    return $this->joueurHumain->getGrille()->getNbNaviresRestants();
    }

    public function getNbNaviresRestantsOrdinateur() {
        return $this->joueurOrdinateur->getGrille()->getNbNaviresRestants();
    }

    /** FIN APPEL DES METHODES DE STATISTIQUES IG */


    /** IMPLéMENTATION DU MISSILE (9cases) */

    public function isMissileUtilise(): bool
    {
        return $this->missileUtilise;
    }

     /**
     * Effectue un tir missile sur une zone 3x3 autour de la case centrale
     * @param int $x : coordonnée x de la case centrale
     * @param int $y : coordonnée y de la case centrale
     * @return void
     */
    public function utiliserMissile(int $x, int $y)
    {
        if (!$this->missileUtilise && $this->estTourJoueurHumain)
        {
            $this->missileUtilise = true;
 
            // Parcourt les 9 cases de la zone 3x3 autour de la case centrale
            for ($i = -1; $i <= 1; $i++)
            {
                for ($j = -1; $j <= 1; $j++)
                {
                    // Vérification des bords de la grille avant de tirer
                    if ($x + $i >= 0 && $x + $i <= 19 && $y + $j >= 0 && $y + $j <= 19)
                    {
                        $this->missileJoueur($x + $i, $y + $j);
                    }
                }
            }
 
            // Après les 9 tirs, passer le tour à l'ordinateur
            $this->estTourJoueurHumain = false;
            if ($this->joueurOrdinateur->getGrille()->toutNaviresCoules())
            {
                $this->finDePartie(true);
            }
            else
            {
                $this->ordinateurJoue();
            }
        }
    }
 
    /**
     * Effectue un tir sur une case de la grille de l'ordinateur sans changer le tour
     * @param int $x : coordonnée x
     * @param int $y : coordonnée y
     * @return void
     */
    private function missileJoueur(int $x, int $y)
    {
        $result = $this->joueurOrdinateur->tirerSurLaCase($x, $y);
 
        // On compte uniquement les tirs valides (pas les répétitions)
        if ($result !== 'repeat')
        {
            $this->tirsJoueur++;
            if ($result === 'coupTouche' || $result === 'coupCoule')
            {
                $this->touchesJoueur++;
            }
        }
    }
 
    /** FIN IMPLÉMENTATION DU MISSILE */


    /**
     * Traitement de la fin de la partie
     * @param bool|null $victoire : true si le joueur a gagné, false si l'ordinateur a gagné, null si partie nulle
     * @return void
     */
    public function proposerNulle()
    {
        $this->finDePartie(null);
    }

    private function finDePartie(?bool $victoire)
    {
        // Mettre à jour les stats si joueur connecté
        if (isset($_SESSION['username'])) {
        $changements = mettreAJourStats($_SESSION['username'], [
            'victoire'       => $victoire,
            'tirs_joueur'    => $this->tirsJoueur,
            'touches_joueur' => $this->touchesJoueur,
        ]);

        // Notification niveau
        if ($changements['nouveau_niveau']) {
            $this->ajouterNotification('niveau', ' Niveau Supérieur' . $changements['nouveau_niveau'] . ' atteint !');
        }

    // Notifications trophées
    foreach ($changements['nouveaux_trophees'] as $trophee) {
        $this->ajouterNotification('trophee', 'Trophée débloqué ! : ' . $trophee);
    }
}
    $_SESSION['notifications_fin'] = $this->notifications;

        $_SESSION['fin_partie'] = [
            'victoire'       => $victoire,
            'nom_joueur'     => $this->joueurHumain->getNom(),
            'role_joueur'    => $this->joueurHumain->getRole(),
            'tirs_joueur'    => $this->tirsJoueur,
            'touches_joueur' => $this->touchesJoueur,
            'tirs_ordi'      => $this->tirsOrdi,
            'touches_ordi'   => $this->touchesOrdi,
            'duree'          => time() - $this->debutPartie,
        ];
        unset($_SESSION['game']);
        header("Location: Findepartie.php");
        exit();
    }

    /**
     * Renvoie la liste des navires du joueur humain
     * @return array La liste des navires
     */
    public function getNaviresJoueur(): array
    {
    return $this->joueurHumain->getGrille()->getNavires();
    }

    /**
     * Renvoie la liste des navires de l'ordinateur
     * @return array La liste des navires
     */
    public function getNaviresOrdinateur(): array
    {
    return $this->joueurOrdinateur->getGrille()->getNavires();
    }

    /** @var array $notifications */
    private array $notifications = [];

    public function getNotifications(): array
    {
    return $this->notifications;
    }

    /**
     * Ajoute une notification à la liste
     * @param string $type : type de notification
     * @param string $message : message de la notification
     * @return void
     */
    private function ajouterNotification(string $type, string $message): void
    {
    $this->notifications[] = ['type' => $type, 'message' => $message];
    }
    /**
     * Vide la liste des notifications
     * @return void
     */
    public function viderNotifications(): void
    {
    $this->notifications = [];
    }
}