<?php
// Chemin vers le fichier JSON
const FICHIER_JOUEURS = __DIR__ . '/joueurs.json';

function getJoueurs() { 
    $contenu = file_get_contents(FICHIER_JOUEURS);
    if ($contenu === false || empty($contenu)) {
        return [];
    }
    $joueurs = json_decode($contenu, true);
    return $joueurs ?? [];
}

function sauvegarderJoueurs($joueurs) { 
    $contenu = json_encode($joueurs, JSON_PRETTY_PRINT);
    file_put_contents(FICHIER_JOUEURS, $contenu);
}

function trouverJoueur($username) { 
    $joueurs = getJoueurs();
    foreach ($joueurs as $joueur) {
        if ($joueur['username'] === $username) {
            return $joueur;
        }
    }
    return null; // Joueur non trouvé
}

function creerJoueur($username, $password) { 
    $joueurs = getJoueurs();
    if (trouverJoueur($username) !== null) {
        return false; // Le nom d'utilisateur existe déjà
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $nouveauJoueur = [
        'username' => $username,
        'password' => $hash,
        'uuid' => strtoupper(substr(md5(uniqid(rand(), true)), 0, 4)),
        'parties_jouees' => 0,
        'parties_gagnees' => 0,
        'xp' => 0,
        'niveau' => 1,
        'tirs_totaux' => 0,
        'touches_totales' => 0,
        'parties_perdues' => 0,
        'parties_nul' => 0,
        'avatars' => [],
        'statut' => 'novice',
        'trophees' => [
        ['nom' => 'premiere_victoire', 'obtenu' => false, 'description' => 'Gagnez votre première partie.'],
        ['nom' => 'premier_bateau', 'obtenu' => false, 'description' => 'Détruisez votre premier bateau.'],
        ['nom' => 'cinquème_victoire', 'obtenu' => false, 'description' => 'Gagnez cinq parties.'],
        ['nom' => 'premier_trophee', 'obtenu' => false, 'description' => 'Obtenez votre premier trophée.']
        ]
    ];
    $joueurs[] = $nouveauJoueur;
    sauvegarderJoueurs($joueurs);
    return true; // Joueur créé avec succès
}

function connecterJoueur($username, $password) { 
    $joueur = trouverJoueur($username);
    if ($joueur && password_verify($password, $joueur['password'])) {
        return $joueur; // Connexion réussie
    }
    return false; // Échec de la connexion
}

function mettreAJourStats($username, $stats) { 
    $joueurs = getJoueurs();
    $changements = ['nouveau_niveau' => false, 'nouveaux_trophees' => []];
    
    foreach ($joueurs as &$joueur) {
        if ($joueur['username'] === $username) {
            $niveauAvant = $joueur['niveau'];
            $tropheesAvant = array_column($joueur['trophees'], 'obtenu');

            $joueur['parties_jouees']++;
            $joueur['tirs_totaux'] += $stats['tirs_joueur'];
            $joueur['touches_totales'] += $stats['touches_joueur'];

            if ($stats['victoire'] === true) {
                $joueur['parties_gagnees']++;
                $joueur['xp'] += 50;
            } elseif ($stats['victoire'] === false) {
                $joueur['parties_perdues']++;
            } else {
                $joueur['parties_nul']++;
            }

            $joueur['niveau'] = calculerNiveau($joueur['xp']);
            $joueur = verifierTrophees($joueur);

            // Détecter niveau gagné
            if ($joueur['niveau'] > $niveauAvant) {
                $changements['nouveau_niveau'] = $joueur['niveau'];
            }

            // Détecter nouveaux trophées
            foreach ($joueur['trophees'] as $i => $trophee) {
                if (!$tropheesAvant[$i] && $trophee['obtenu']) {
                    $changements['nouveaux_trophees'][] = $trophee['nom'];
                }
            }
            break;
        }
    }
    sauvegarderJoueurs($joueurs);
    return $changements;
}

function verifierTrophees($joueur) { 
    if (!$joueur['trophees'][0]['obtenu'] && $joueur['parties_gagnees'] >= 1) {
        $joueur['trophees'][0]['obtenu'] = true;
    }
    if (!$joueur['trophees'][1]['obtenu'] && $joueur['touches_totales'] >= 5) {
        $joueur['trophees'][1]['obtenu'] = true;
    }
    if (!$joueur['trophees'][2]['obtenu'] && $joueur['parties_gagnees'] >= 5) {
        $joueur['trophees'][2]['obtenu'] = true;
    }

    $unTropheeObtenu = false;
    foreach ($joueur['trophees'] as $trophee) {
        if ($trophee['obtenu'] === true) {
            $unTropheeObtenu = true;
            break;
        }
    }

    if (!$joueur['trophees'][3]['obtenu'] && $unTropheeObtenu) {
        $joueur['trophees'][3]['obtenu'] = true;
    }
    
    return $joueur;
}

function calculerNiveau($xp) {
    if ($xp >= 800) return 6;
    if ($xp >= 600) return 5;
    if ($xp >= 400) return 4;
    if ($xp >= 250) return 3;
    if ($xp >= 100) return 2;
    return 1;
}

function getClassement() {
    $joueurs = getJoueurs();
    // Calculer la précision pour chaque joueur
    foreach ($joueurs as &$joueur) {
        $joueur['precision'] = $joueur['tirs_totaux'] > 0
            ? round($joueur['touches_totales'] / $joueur['tirs_totaux'] * 100)
            : 0;
    }
    // Trier par victoires décroissantes
    usort($joueurs, fn($a, $b) => $b['parties_gagnees'] <=> $a['parties_gagnees']);
    return $joueurs;
}

function getStatsGlobales() {
    $joueurs = getJoueurs();
    $totalParties = array_sum(array_column($joueurs, 'parties_jouees'));
    $totalTirs    = array_sum(array_column($joueurs, 'tirs_totaux'));
    $totalTouches = array_sum(array_column($joueurs, 'touches_totales'));
    return [
        'total_parties'  => $totalParties,
        'total_joueurs'  => count($joueurs),
        'precision_moy'  => $totalTirs > 0 ? round($totalTouches / $totalTirs * 100) : 0,
    ];
}


?>