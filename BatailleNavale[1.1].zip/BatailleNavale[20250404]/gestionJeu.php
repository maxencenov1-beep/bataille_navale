<?php
/*
 * Interface principale du jeu
 * Contient en partie gauche :
 *      la grille du joueur, en lecture seule. L'ordinateur affiche ses coups sur cette partie
 * Contient en partie droite :
 *      la grille de l'ordinateur. L'utilisateur peut sélectionner une case pour tirer
 *      Les coups du joueur sont affiché sur cette partie
 * */
require_once 'classes/Partie.php';
require_once 'classes/JoueurHumain.php';
require_once 'classes/JoueurOrdinateur.php';
require_once 'classes/Grille.php';
require_once 'classes/Navire.php';

session_start();

// Générer un ID unique pour identifier le joueur (invité)
if (!isset($_SESSION['player_uuid'])) {
    $_SESSION['player_uuid'] = strtoupper(substr(md5(uniqid(rand(), true)), 0, 4));
}

// Si connecté → utiliser l'UUID du compte, sinon celui de la session
$playerUuid = isset($_SESSION['username']) 
    ? trouverJoueur($_SESSION['username'])['uuid'] 
    : 'Invité';


// Récupération du nom du joueur la première fois
if (!isset($_SESSION['game']))
{
    $_SESSION['game'] = new Partie($_POST['nomJoueur'], $_POST['roleJoueur'], $_POST['difficulte']);
    $_SESSION['difficulte'] = $_POST['difficulte'];

    // Choisir un fond aléatoire au début de la partie (1 seule fois)
    $fonds = [
        'ocean_pixel.png',
        'ocean_tropical.png',
        'ocean_arctique.png',
        'ocean_tempete.png',
        'ocean_couchant.png',
        'ocean_nuit.png',
        'ocean_brume.png',
        'ocean_aube.png',
    ];
    $_SESSION['fond_ocean'] = $fonds[array_rand($fonds)];
}

// Fond sélectionné pour cette partie
$fondOcean = $_SESSION['fond_ocean'] ?? 'ocean_pixel.png';

// Récupération de la partie en cours
$partie = $_SESSION['game'];

// Traitement des coordonnées envoyées par le formulaire
if (isset($_POST['coord']))
{
    list($x, $y) = explode(',', $_POST['coord']);
    $partie->joueurJoue($x, $y);
}

// Traitement de la fin de partie provoquée par l'utilisateur (clic sur le bouton Capituler)
if (isset($_POST['end_game'])) {
    unset($_SESSION['game']);  // supprime seulement la partie et na pas besin de supprimer les autre donnés de session comme le nom du joueur
    header("Location: index.php");
    exit();
}


// Traitement de l'utilisation du missile
if (isset($_POST['use_missile'])){
    $_SESSION['missile_actif'] = true;
}

if (isset($_POST['coord']))
{
    list($x, $y) = explode(',', $_POST['coord']);
    if (!empty($_POST['missile'])) {
        $partie->utiliserMissile($x, $y);
        unset($_SESSION['missile_actif']);
    } else {
        $partie->joueurJoue($x, $y);
    }
}

// Traitement de la proposition de partie nulle
if (isset($_POST['propose_nulle'])) {
    $partie->proposerNulle();
}

// Récupérer les notifications de la partie
$notifications = $partie->getNotifications();
$partie->viderNotifications();
// Récupération de la grille du joueur
$playerGrid = $partie->getJoueurGrille();
// Récupération de la grille de l'ordinateur
$computerGrid = $partie->getOrdinateurGrille();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bataille Navale</title>
    <link rel="stylesheet" href="css/game.css">
    <style>
        :root {
            --bg-ocean: url('../images/<?php echo $fondOcean; ?>');
        }
    </style>
</head>
<body>
<div class="grid-container">
    <div class="grid-item">Bataille Navale</div>
    <div class="grid-item two-columns">
        <div>
        <?php echo $partie->getRoleJoueur() . ' ' . $partie->getNomJoueur(); ?>
            <?php if ($playerUuid !== 'Invité'): ?>
        #<?php echo $playerUuid; ?>
        <?php else: ?>
            #Invité
        <?php endif; ?>
        </div>
        <div><?php echo $partie->getNomOrdinateur(); ?></div>
    </div>
    <div class="grid-item two-columns">
        <div>
            <div class="grid">
                <?php foreach ($playerGrid as $row): ?>
                    <div>
                        <?php foreach ($row as $cell): ?>
                            <button type="none" class='cellJoueur <?php echo $cell; ?> disabled'></button>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div>
            <div class="grid">
                <form action="gestionJeu.php" method="post">
                    <?php if (!empty($_SESSION['missile_actif'])): ?>
                        <input type="hidden" name="missile" value="1">
                    <?php endif; ?>
                    <?php foreach ($computerGrid as $y => $row): ?>
                        <div>
                            <?php foreach ($row as $x => $cell): ?>
                                <?php $dejaJouee = in_array($cell, ['coupRate', 'coupTouche', 'coupCoule']); ?>
                                <button type="submit" name="coord" value='<?php echo $x . ',' . $y; ?>' class='cellOrdinateur <?php echo $cell; ?>' <?php echo (!$partie->estTourJoueur() || $dejaJouee) ? 'disabled' : ''; ?>></button>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </form>
            </div>
        </div>
    </div>
    <div class="grid-item two-columns">
       <div>Stats Joueur :
            <?php foreach ($partie->getNaviresJoueur() as $navire): ?>
        <div style="margin-left: 10px;">
            <?php echo $navire->getNom(); ?> :
            <?php echo str_repeat('❤️', $navire->getPv()); ?>
            <?php echo str_repeat('🖤', $navire->getTaille() - $navire->getPv()); ?>
        </div>
            <?php endforeach; ?>
        <div style="margin-left: 10px;">Tirs : <?php echo $partie->getTirsJoueur() ?></div>
        <div style="margin-left: 10px;">Touches : <?php echo $partie->getTouchesJoueur() ?></div>
    </div>
        <div>Stats Ordinateur :
            <?php foreach ($partie->getNaviresOrdinateur() as $navire): ?>
        <div style="margin-left: 10px;">
            <?php echo $navire->getNom(); ?> :
            <?php echo str_repeat('❤️', $navire->getPv()); ?>
            <?php echo str_repeat('🖤', $navire->getTaille() - $navire->getPv()); ?>
        </div>
            <?php endforeach; ?>
        <div style="margin-left: 10px;">Tirs : <?php echo $partie->getTirsOrdi() ?></div>
        <div style="margin-left: 10px;">Touches : <?php echo $partie->getTouchesOrdi() ?></div>
        </div>
    </div>
    <div class="grid-item">
        <form action="gestionJeu.php" method="post" style="margin-top: 5px;">
            <button type="submit" name="propose_nulle" value="1">Partie nulle</button>
            <button type="submit" name="end_game" value="1">Capituler</button>
            <button type="submit" name="use_missile" value="1" <?php echo $partie->isMissileUtilise() ? 'disabled' : ''; ?>>Missile</button>
        </form>
    </div>

    <!-- Notifications -->
    <div id="notifications">
        <?php foreach ($notifications as $notif): ?>
            <div class="notif <?php echo $notif['type']; ?>">
                <?php echo $notif['message']; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        // Supprimer chaque notification après 4 seconde
        document.querySelectorAll('.notif').forEach(function(notif) {
        setTimeout(function() {
                notif.remove();
            }, 4000);
        });
    </script>
</div>
</body>
</html>