<?php
session_start();
require_once 'data/database.php';

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bataille Navale</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1>Bataille Navale</h1>
<?php if (isset($_SESSION['username'])): 
    $joueur = trouverJoueur($_SESSION['username']); ?>
    
    <p>Bonjour <?php echo $joueur['username']; ?> - Niveau <?php echo $joueur['niveau']; ?> - <?php echo $joueur['xp']; ?> XP</p>
    <form action="gestionJeu.php" method="post">
        <input type="hidden" name="nomJoueur" value="<?php echo $joueur['username']; ?>">
        <select id="roleJoueur" name="roleJoueur" required>
            <option value="Matelot">Matelot</option>
            <option value="Sous-officier">Sous-officier</option>
            <option value="Officier">Officier</option>
            <option value="Lieutenant">Lieutenant</option>
            <option value="Capitaine">Capitaine</option>
            <option value="Amiral">Amiral</option>
            
        </select>

    <label for="difficulte">Difficulté :</label>
        <select id="difficulte" name="difficulte" required>
            <option value="nul">Nul</option>
            <option value="facile">Facile</option>
            <option value="moyen" selected>Moyen</option>
            <option value="difficile">Difficile</option>
            <option value="impossible">Impossible (triche)</option>
        </select>
        <button type="submit">Commencer la partie</button>

    </form>
    <button><a href="profil.php">Mon profil</a></button>
    <button><a href="classement.php">Classement</a></button>
    <button><a href="deconnexion.php">Se déconnecter</a></button>


<?php else : ?>
    <p>Bienvenue sur Bataille Navale ! Connectez-vous pour suivre votre progression ou juste jouer</p>
    <form action="gestionJeu.php" method="post">
        <label for="nomJoueur">Nom du joueur :</label>
        
        <input type="text" id="nomJoueur" name="nomJoueur" required>
        <label for="roleJoueur">Rôle :</label>
        <select id="roleJoueur" name="roleJoueur" required>
            <option value="Matelot">Matelot</option>
            <option value="Sous-officier">Sous-officier</option>
            <option value="Officier">Officier</option>
            <option value="Lieutenant">Lieutenant</option>
            <option value="Capitaine">Capitaine</option>
            <option value="Amiral">Amiral</option>
            
        </select>

        <label for="difficulte">Difficulté :</label>
        <select id="difficulte" name="difficulte" required>
            <option value="nul">Nul</option>
            <option value="facile">Facile</option>
            <option value="moyen" selected>Moyen</option>
            <option value="difficile">Difficile</option>
            <option value="impossible">Impossible (triche)</option>
        </select>

        <button type="submit">Commencer la partie</button>
    </form>
    <button><a href="auth.php">Se connecter</a></button>
    <button><a href="classement.php">Classement</a></button>
<?php endif; ?>
</div>
</body>
</html>