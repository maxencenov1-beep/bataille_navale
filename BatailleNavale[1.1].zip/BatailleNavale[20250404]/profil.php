<?php
session_start();
require_once 'data/database.php';

// Si non connecté → rediriger
if (!isset($_SESSION['username'])) {
    header('Location: auth.php');
    exit();
}

// Récupérer les données du joueur
$joueur = trouverJoueur($_SESSION['username']);

// Calculer la précision
$precision = $joueur['tirs_totaux'] > 0 
    ? round($joueur['touches_totales'] / $joueur['tirs_totaux'] * 100) 
    : 0;

// Calculer la progression vers le niveau suivant
$seuilsXP = [0, 100, 250, 400, 600, 800];
$niveauActuel = $joueur['niveau'];
$xpActuel = $joueur['xp'];

if ($niveauActuel >= 6) {
    $progression = 100;
} else {
    $xpNiveauActuel = $seuilsXP[$niveauActuel - 1];
    $xpNiveauSuivant = $seuilsXP[$niveauActuel];
    $progression = round(($xpActuel - $xpNiveauActuel) / ($xpNiveauSuivant - $xpNiveauActuel) * 100);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bataille Navale</title>
    <link rel="stylesheet" href="css/profil.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@700&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1><?php echo $joueur['username']; ?> - #<?php echo $joueur['uuid']; ?></h1>
    <p>Niveau <?php echo $joueur['niveau']; ?> - <?php echo $joueur['xp']; ?> XP</p>

    <!-- Barre de progression -->
    <div class="barre-fond">
        <div class="barre-progression" style="width: <?php echo $progression; ?>%"></div>
    </div>

    <!-- Stats -->
    <p>Parties jouées : <?php echo $joueur['parties_jouees']; ?></p>
    <p>Tirs effectués : <?php echo $joueur['tirs_totaux']; ?></p>
    <p>Touches : <?php echo $joueur['touches_totales']; ?></p>
    <p>Précision : <?php echo $precision; ?>%</p>
    <p>Victoires : <?php echo $joueur['parties_gagnees']; ?></p>
    <p>Défaites : <?php echo $joueur['parties_perdues']; ?></p>
    <p>Nuls : <?php echo $joueur['parties_nul']; ?></p>

    <!-- Trophées -->
    <?php foreach ($joueur['trophees'] as $trophee): ?>
        <div class="trophee <?php echo $trophee['obtenu'] ? 'obtenu' : ''; ?>">
            <h3><?php echo $trophee['nom']; ?></h3>
            <p><?php echo $trophee['description']; ?></p>
        </div>
    <?php endforeach; ?>
    <button><a href="index.php">Retour</a></button>
</div>
</body>
</html>